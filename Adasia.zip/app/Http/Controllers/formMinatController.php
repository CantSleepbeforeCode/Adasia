<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class formMinatController extends Controller
{
    //
}
